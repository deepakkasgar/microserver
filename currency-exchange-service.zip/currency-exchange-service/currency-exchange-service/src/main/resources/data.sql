insert into currency_exchange(id,currency_from,currency_to,conversion_multiple,environment) values(1001,'USD','INR',75,'');
insert into currency_exchange(id,currency_from,currency_to,conversion_multiple,environment) values(1002,'NZUSD','INR',80,'');
insert into currency_exchange(id,currency_from,currency_to,conversion_multiple,environment) values(1003,'AUSD','INR',65,'');
insert into currency_exchange(id,currency_from,currency_to,conversion_multiple,environment) values(1004,'DINAR','INR',115,'');